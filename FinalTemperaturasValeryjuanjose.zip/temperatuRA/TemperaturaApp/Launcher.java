package TemperaturaApp;

public class Launcher {
    public static void main(String[] args) {
        new VentanaPrincipal();
    }
}
